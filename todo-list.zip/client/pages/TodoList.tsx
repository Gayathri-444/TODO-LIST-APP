import { Link } from 'react-router-dom';
import { Plus, Edit3, Trash2, Check } from 'lucide-react';
import { useTodos } from '../contexts/TodoContext';

export default function TodoList() {
  const { todos, toggleTodo, deleteTodo } = useTodos();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold tracking-wide">TODO APP</h1>
          <div className="flex items-center space-x-2">
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-4 h-2 bg-white rounded-sm"></div>
          </div>
        </div>
        <div className="text-xs opacity-90 mt-1">9:41</div>
      </div>

      {/* Todo List */}
      <div className="px-6 py-4 space-y-3">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className="bg-white rounded-lg p-4 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className={`font-medium text-gray-900 ${todo.completed ? 'line-through text-gray-500' : ''}`}>
                  {todo.title}
                </h3>
                <p className={`text-sm text-gray-600 mt-1 ${todo.completed ? 'line-through text-gray-400' : ''}`}>
                  {todo.description}
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                {todo.completed ? (
                  <button
                    onClick={() => toggleTodo(todo.id)}
                    className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center"
                  >
                    <Check size={14} className="text-white" />
                  </button>
                ) : (
                  <>
                    <Link 
                      to={`/edit/${todo.id}`}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <Edit3 size={18} />
                    </Link>
                    <button
                      onClick={() => deleteTodo(todo.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 size={18} />
                    </button>
                    <button
                      onClick={() => toggleTodo(todo.id)}
                      className="w-6 h-6 border-2 border-gray-300 rounded-full hover:border-green-500"
                    >
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Floating Add Button */}
      <Link
        to="/add"
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow"
      >
        <Plus size={24} />
      </Link>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          </div>
          <div className="w-8 h-1 bg-gray-300 rounded-full"></div>
          <div className="w-6 h-6 border border-gray-300 rounded"></div>
        </div>
      </div>
    </div>
  );
}
