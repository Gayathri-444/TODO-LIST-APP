import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useTodos } from '../contexts/TodoContext';

export default function EditTask() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getTodo, updateTodo, deleteTodo } = useTodos();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (id) {
      const todo = getTodo(id);
      if (todo) {
        setTitle(todo.title);
        setDescription(todo.description);
      } else {
        navigate('/');
      }
    }
  }, [id, getTodo, navigate]);

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && id) {
      updateTodo(id, title, description);
      navigate('/');
    }
  };

  const handleDelete = () => {
    if (id && window.confirm('Are you sure you want to delete this task?')) {
      deleteTodo(id);
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-primary-foreground">
              <ArrowLeft size={20} />
            </Link>
            <h1 className="text-lg font-semibold tracking-wide">Edit Task</h1>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-4 h-2 bg-white rounded-sm"></div>
          </div>
        </div>
        <div className="text-xs opacity-90 mt-1">9:41</div>
      </div>

      {/* Form */}
      <div className="px-6 py-8">
        <form onSubmit={handleUpdate} className="space-y-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
              Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-colors"
              placeholder="Enter task title"
              required
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-colors resize-none"
              placeholder="Enter task description"
            />
          </div>

          <div className="space-y-3">
            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors"
            >
              UPDATE
            </button>
            
            <button
              type="button"
              onClick={handleDelete}
              className="w-full bg-red-500 text-white py-4 rounded-lg font-semibold text-lg hover:bg-red-600 transition-colors"
            >
              DELETE
            </button>
          </div>
        </form>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          </div>
          <div className="w-8 h-1 bg-gray-300 rounded-full"></div>
          <div className="w-6 h-6 border border-gray-300 rounded"></div>
        </div>
      </div>
    </div>
  );
}
