import { createContext, useContext, useState, ReactNode } from 'react';

export interface Todo {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

interface TodoContextType {
  todos: Todo[];
  addTodo: (title: string, description: string) => void;
  updateTodo: (id: string, title: string, description: string) => void;
  deleteTodo: (id: string) => void;
  toggleTodo: (id: string) => void;
  getTodo: (id: string) => Todo | undefined;
}

const TodoContext = createContext<TodoContextType | undefined>(undefined);

export function TodoProvider({ children }: { children: ReactNode }) {
  const [todos, setTodos] = useState<Todo[]>([
    {
      id: '1',
      title: 'TODO TITLE',
      description: 'TODO SUB TITLE',
      completed: false,
    },
    {
      id: '2',
      title: 'TODO TITLE',
      description: 'TODO SUB TITLE',
      completed: true,
    },
    {
      id: '3',
      title: 'TODO TITLE',
      description: 'TODO SUB TITLE',
      completed: true,
    },
    {
      id: '4',
      title: 'TODO TITLE',
      description: 'TODO SUB TITLE',
      completed: false,
    },
    {
      id: '5',
      title: 'TODO TITLE',
      description: 'TODO SUB TITLE',
      completed: false,
    },
  ]);

  const addTodo = (title: string, description: string) => {
    const newTodo: Todo = {
      id: Date.now().toString(),
      title,
      description,
      completed: false,
    };
    setTodos(prev => [...prev, newTodo]);
  };

  const updateTodo = (id: string, title: string, description: string) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id ? { ...todo, title, description } : todo
    ));
  };

  const deleteTodo = (id: string) => {
    setTodos(prev => prev.filter(todo => todo.id !== id));
  };

  const toggleTodo = (id: string) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const getTodo = (id: string) => {
    return todos.find(todo => todo.id === id);
  };

  return (
    <TodoContext.Provider value={{
      todos,
      addTodo,
      updateTodo,
      deleteTodo,
      toggleTodo,
      getTodo
    }}>
      {children}
    </TodoContext.Provider>
  );
}

export function useTodos() {
  const context = useContext(TodoContext);
  if (context === undefined) {
    throw new Error('useTodos must be used within a TodoProvider');
  }
  return context;
}
